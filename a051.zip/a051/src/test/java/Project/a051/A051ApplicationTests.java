package Project.a051;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class A051ApplicationTests {

	@Test
	void contextLoads() {
	}

}
