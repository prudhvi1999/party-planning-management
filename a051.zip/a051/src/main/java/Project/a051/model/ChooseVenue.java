package Project.a051.model;

public class ChooseVenue {
	private String venue;

	public String getVenue() {
		return venue;
	}

	public void setVenue(String venue) {
		this.venue = venue;
	}
}
