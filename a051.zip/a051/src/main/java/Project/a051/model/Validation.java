package Project.a051.model;

public class Validation {
	String sq1;
    String sq2;
    String sq3;
    String userid;
    public String getSq1() {
          return sq1;
    }
    public void setSq1(String sq1) {
          this.sq1 = sq1;
    }
    public String getSq2() {
          return sq2;
    }
    public void setSq2(String sq2) {
          this.sq2 = sq2;
    }
    public String getSq3() {
          return sq3;
    }
    public void setSq3(String sq3) {
          this.sq3 = sq3;
    }
    public String getUserid() {
          return userid;
    }
    public void setUserid(String userid) {
          this.userid = userid;
    }
}
