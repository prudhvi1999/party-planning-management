package Project.a051.model;

public class resetpwd {
	String newPassword;
}
